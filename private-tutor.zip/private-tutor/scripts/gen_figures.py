#!/usr/bin/env python3
"""生成数学试卷所需的所有几何图形"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import os

os.makedirs('/Users/chebailin/WorkBuddy/Claw/team-mode/私家家教/每日试卷/figures', exist_ok=True)
FIGDIR = '/Users/chebailin/WorkBuddy/Claw/team-mode/私家家教/每日试卷/figures'

plt.rcParams['font.family'] = ['Arial Unicode MS', 'STHeiti', 'Heiti TC', 'sans-serif']
plt.rcParams['axes.unicode_minus'] = False

# ===== 图1: 第6题 直角三角形 sinA =====
fig, ax = plt.subplots(figsize=(3.2, 2.6))
ax.set_xlim(-0.4, 1.6)
ax.set_ylim(-0.3, 1.5)
ax.set_aspect('equal')
B, C, A = (0, 0), (1.0, 0), (0, 0.75)
tri = plt.Polygon([B, C, A], fill=False, edgecolor='black', linewidth=2)
ax.add_patch(tri)
sq = patches.Rectangle((0, 0), 0.06, 0.06, fill=False, edgecolor='black', linewidth=1.5)
ax.add_patch(sq)
ax.text(-0.15, 0.75, 'A', fontsize=13, ha='center', va='center', fontweight='bold')
ax.text(-0.12, -0.05, 'B', fontsize=13, ha='center', va='center', fontweight='bold')
ax.text(1.12, -0.05, 'C', fontsize=13, ha='center', va='center', fontweight='bold')
ax.text(-0.22, 0.375, 'AC=3', fontsize=9, ha='center', va='center', color='#555', rotation=90)
ax.text(0.5, -0.17, 'BC=4', fontsize=9, ha='center', va='center', color='#555')
# 斜边标注
ax.text(0.58, 0.42, 'AB=5', fontsize=9, ha='center', va='center', color='#1a6eff', rotation=-37)
ax.axis('off')
fig.tight_layout(pad=0.4)
fig.savefig(f'{FIGDIR}/fig6_triangle.png', dpi=150, bbox_inches='tight', facecolor='white')
plt.close()
print('✓ fig6_triangle.png')

# ===== 图2: 第9题 平行线 =====
fig, ax = plt.subplots(figsize=(3.8, 3.0))
ax.set_xlim(0, 5)
ax.set_ylim(0, 4)
# 两条平行横线
ax.plot([0.4, 4.2], [2.8, 2.8], 'b-', linewidth=2)
ax.plot([0.4, 4.2], [1.2, 1.2], 'b-', linewidth=2)
ax.text(4.3, 2.8, '$l_1$', fontsize=12, va='center', color='blue')
ax.text(4.3, 1.2, '$l_2$', fontsize=12, va='center', color='blue')
# 箭头表示平行
ax.annotate('', xy=(1.8, 2.8), xytext=(1.5, 2.8), arrowprops=dict(arrowstyle='->', color='blue', lw=1.2))
ax.annotate('', xy=(1.8, 1.2), xytext=(1.5, 1.2), arrowprops=dict(arrowstyle='->', color='blue', lw=1.2))
# 截线 l3（从左下到右上）
x0, x1 = 1.2, 3.3
y0, y1 = 0.3, 3.9
ax.plot([x0, x1], [y0, y1], 'k-', linewidth=2)
ax.text(x1 + 0.05, y1, '$l_3$', fontsize=12, va='bottom')

# 计算截点
# l1: y=2.8, l2: y=1.2
slope = (y1 - y0) / (x1 - x0)
# x = x0 + (y - y0) / slope
def xat(y):
    return x0 + (y - y0) / slope

px1, py1 = xat(2.8), 2.8
px2, py2 = xat(1.2), 1.2
ax.plot(px1, py1, 'ko', markersize=4)
ax.plot(px2, py2, 'ko', markersize=4)

# ∠1 在 l1 截点上方右侧（锐角标注）
arc1 = patches.Arc((px1, py1), 0.5, 0.5, angle=0, theta1=0, theta2=65, color='red', lw=1.5)
ax.add_patch(arc1)
ax.text(px1 + 0.35, py1 + 0.2, '∠1=65°', fontsize=9, color='red')

# ∠2 在 l2 截点左下侧（同旁内角）
arc2 = patches.Arc((px2, py2), 0.5, 0.5, angle=0, theta1=180, theta2=180+115, color='darkblue', lw=1.5)
ax.add_patch(arc2)
ax.text(px2 - 1.0, py2 - 0.35, '∠2=?', fontsize=9, color='darkblue')

ax.axis('off')
fig.tight_layout(pad=0.4)
fig.savefig(f'{FIGDIR}/fig9_parallel.png', dpi=150, bbox_inches='tight', facecolor='white')
plt.close()
print('✓ fig9_parallel.png')

# ===== 图3: 第13题 旋转变换 =====
fig, ax = plt.subplots(figsize=(3.5, 3.2))
ax.set_xlim(-2.2, 2.2)
ax.set_ylim(-1.5, 2.5)
ax.set_aspect('equal')
O = np.array([0.0, 0.0])
r = 1.6
# 原三角形顶点
A = np.array([r, 0])
B = np.array([r * np.cos(np.radians(50)), r * np.sin(np.radians(50))])
C = np.array([0.8, 0.3])
# 旋转60度
theta = np.radians(60)
rot = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
A2 = rot @ A
B2 = rot @ B
C2 = rot @ C

tri1 = plt.Polygon([A, B, C], fill=True, facecolor='#cce0ff', edgecolor='#1a6eff', linewidth=1.8, alpha=0.7)
ax.add_patch(tri1)
tri2 = plt.Polygon([A2, B2, C2], fill=True, facecolor='#ffe0cc', edgecolor='#ff6a1a', linewidth=1.8, linestyle='--', alpha=0.7)
ax.add_patch(tri2)
ax.plot(*O, 'ko', markersize=6, zorder=5)
ax.text(-0.18, -0.18, 'O', fontsize=11, fontweight='bold')
ax.text(A[0] + 0.08, A[1] - 0.05, 'A', fontsize=11, color='#1a6eff', fontweight='bold')
ax.text(A2[0] - 0.05, A2[1] + 0.1, "A'", fontsize=11, color='#ff6a1a', fontweight='bold')
ax.text(B[0] + 0.05, B[1] + 0.05, 'B', fontsize=9, color='#1a6eff')
ax.text(B2[0] - 0.2, B2[1] + 0.05, "B'", fontsize=9, color='#ff6a1a')
ax.plot([O[0], A[0]], [O[1], A[1]], 'k--', linewidth=0.9, alpha=0.6)
ax.plot([O[0], A2[0]], [O[1], A2[1]], 'k--', linewidth=0.9, alpha=0.6)
arc = patches.Arc((0, 0), 1.0, 1.0, angle=0, theta1=0, theta2=60, color='green', lw=2)
ax.add_patch(arc)
ax.text(0.62, 0.38, '60°', fontsize=9, color='green', fontweight='bold')
ax.axis('off')
fig.tight_layout(pad=0.4)
fig.savefig(f'{FIGDIR}/fig13_rotation.png', dpi=150, bbox_inches='tight', facecolor='white')
plt.close()
print('✓ fig13_rotation.png')

# ===== 图4: 第14题 平移变换 =====
fig, ax = plt.subplots(figsize=(4.2, 3.5))
ax.set_xlim(-2.5, 5)
ax.set_ylim(-0.8, 3.2)
ax.set_aspect('equal')
ax.axhline(0, color='black', linewidth=0.8)
ax.axvline(0, color='black', linewidth=0.8)
ax.annotate('', xy=(4.8, 0), xytext=(4.5, 0), arrowprops=dict(arrowstyle='->', color='black', lw=1))
ax.annotate('', xy=(0, 3.0), xytext=(0, 2.7), arrowprops=dict(arrowstyle='->', color='black', lw=1))
ax.text(4.85, 0, 'x', fontsize=10, va='center')
ax.text(0.1, 3.05, 'y', fontsize=10, ha='left')
A1, B1, C1 = [1, 0], [3, 0], [2, 2]
tri1 = plt.Polygon([A1, B1, C1], fill=True, facecolor='#cce0ff', edgecolor='#1a6eff', linewidth=1.8, alpha=0.8)
ax.add_patch(tri1)
ax.text(1, -0.3, 'A(1,0)', fontsize=8, ha='center', color='#1a6eff')
ax.text(3, -0.3, 'B(3,0)', fontsize=8, ha='center', color='#1a6eff')
ax.text(2.15, 2.1, 'C(2,2)', fontsize=8, ha='left', color='#1a6eff')
A2, B2, C2 = [-1, 0], [1, 0], [0, 2]
tri2 = plt.Polygon([A2, B2, C2], fill=True, facecolor='#ffe0cc', edgecolor='#ff6a1a', linewidth=1.8, linestyle='--', alpha=0.8)
ax.add_patch(tri2)
ax.text(-1, -0.3, "A'(-1,0)", fontsize=8, ha='center', color='#ff6a1a')
ax.text(1, -0.5, "B'(1,0)", fontsize=8, ha='center', color='#ff6a1a')
ax.text(0.1, 2.1, "C'(0,2)", fontsize=8, ha='left', color='#ff6a1a')
ax.annotate('', xy=(0.0, 1.2), xytext=(1.8, 1.2),
            arrowprops=dict(arrowstyle='->', color='green', lw=2))
ax.text(0.9, 1.45, '向左平移2', fontsize=8, ha='center', color='green')
for i in range(-2, 5):
    ax.text(i, -0.18, str(i), fontsize=7, ha='center', color='gray')
for i in range(1, 3):
    ax.text(-0.18, i, str(i), fontsize=7, ha='center', color='gray')
ax.set_xlim(-2.5, 5)
ax.set_ylim(-0.8, 3.2)
ax.axis('off')
ax.axhline(0, color='black', linewidth=0.8)
ax.axvline(0, color='black', linewidth=0.8)
ax.annotate('', xy=(4.8, 0), xytext=(4.5, 0), arrowprops=dict(arrowstyle='->', color='black', lw=1))
ax.annotate('', xy=(0, 3.0), xytext=(0, 2.7), arrowprops=dict(arrowstyle='->', color='black', lw=1))
ax.text(4.85, 0, 'x', fontsize=10, va='center')
ax.text(0.1, 3.05, 'y', fontsize=10)
fig.tight_layout(pad=0.4)
fig.savefig(f'{FIGDIR}/fig14_translation.png', dpi=150, bbox_inches='tight', facecolor='white')
plt.close()
print('✓ fig14_translation.png')

# ===== 图5: 第22题 坐标系中A(0,3)和B(4,0) =====
fig, ax = plt.subplots(figsize=(3.8, 3.5))
ax.set_xlim(-0.5, 5.5)
ax.set_ylim(-0.5, 4)
ax.set_aspect('equal')
ax.axhline(0, color='black', linewidth=0.8)
ax.axvline(0, color='black', linewidth=0.8)
ax.annotate('', xy=(5.2, 0), xytext=(4.9, 0), arrowprops=dict(arrowstyle='->', color='black', lw=1))
ax.annotate('', xy=(0, 3.8), xytext=(0, 3.5), arrowprops=dict(arrowstyle='->', color='black', lw=1))
ax.text(5.25, 0, 'x', fontsize=10, va='center')
ax.text(0.1, 3.85, 'y', fontsize=10)
ax.plot(0, 3, 'bo', markersize=6)
ax.plot(4, 0, 'bo', markersize=6)
ax.text(-0.35, 3, 'A(0,3)', fontsize=10, ha='right', va='center', color='blue', fontweight='bold')
ax.text(4, -0.35, 'B(4,0)', fontsize=10, ha='center', va='top', color='blue', fontweight='bold')
ax.plot([0, 4], [3, 0], 'b-', linewidth=2)
# 中点
ax.plot(2, 1.5, 'rs', markersize=5)
ax.text(2.15, 1.6, 'M(2, 1.5)', fontsize=8, color='red')
for i in range(1, 5):
    ax.plot(i, 0, 'k|', markersize=4)
    ax.text(i, -0.2, str(i), fontsize=7, ha='center', color='gray')
for i in range(1, 4):
    ax.plot(0, i, 'k_', markersize=4)
    ax.text(-0.2, i, str(i), fontsize=7, ha='center', color='gray')
ax.axis('off')
ax.axhline(0, color='black', linewidth=0.8)
ax.axvline(0, color='black', linewidth=0.8)
ax.annotate('', xy=(5.2, 0), xytext=(4.9, 0), arrowprops=dict(arrowstyle='->', color='black', lw=1))
ax.annotate('', xy=(0, 3.8), xytext=(0, 3.5), arrowprops=dict(arrowstyle='->', color='black', lw=1))
ax.text(5.25, 0, 'x', fontsize=10, va='center')
ax.text(0.1, 3.85, 'y', fontsize=10)
fig.tight_layout(pad=0.4)
fig.savefig(f'{FIGDIR}/fig22_coordinates.png', dpi=150, bbox_inches='tight', facecolor='white')
plt.close()
print('✓ fig22_coordinates.png')

# ===== 图6: 第24题 正方形ABCD =====
fig, ax = plt.subplots(figsize=(3.2, 3.2))
ax.set_xlim(-0.5, 5.5)
ax.set_ylim(-0.5, 5.5)
ax.set_aspect('equal')
A, B, C, D = (0, 0), (4, 0), (4, 4), (0, 4)
sq = plt.Polygon([A, B, C, D], fill=True, facecolor='#e8f4e8', edgecolor='black', linewidth=2)
ax.add_patch(sq)
E = (4, 2)  # BC中点
F = (3, 4)  # CD上CF=1
ax.plot(*E, 'ro', markersize=6)
ax.plot(*F, 'ro', markersize=6)
ax.plot([E[0], F[0]], [E[1], F[1]], 'r-', linewidth=2)
# 顶点标注
ax.text(-0.2, -0.15, 'A', fontsize=12, fontweight='bold')
ax.text(4.15, -0.15, 'B', fontsize=12, fontweight='bold')
ax.text(4.15, 4.1, 'C', fontsize=12, fontweight='bold')
ax.text(-0.3, 4.1, 'D', fontsize=12, fontweight='bold')
ax.text(4.15, 2.0, 'E', fontsize=11, color='red', va='center')
ax.text(F[0] - 0.35, F[1] + 0.15, 'F', fontsize=11, color='red')
# 标注尺寸
ax.text(2, -0.3, 'AB=4', fontsize=9, ha='center', color='gray')
ax.text(4.5, 3, 'BE=2', fontsize=9, ha='left', color='gray')
ax.text(3.3, 4.25, 'CF=1', fontsize=9, ha='center', color='gray')
# 直角标记
for corner_x, corner_y in [(0, 0), (4, 0), (4, 4), (0, 4)]:
    ax.plot([corner_x + (0.2 if corner_x == 0 else -0.2), corner_x + (0.2 if corner_x == 0 else -0.2)],
            [corner_y, corner_y + (0.2 if corner_y == 0 else -0.2)], 'k-', lw=1)
    ax.plot([corner_x, corner_x + (0.2 if corner_x == 0 else -0.2)],
            [corner_y + (0.2 if corner_y == 0 else -0.2), corner_y + (0.2 if corner_y == 0 else -0.2)], 'k-', lw=1)
ax.axis('off')
fig.tight_layout(pad=0.4)
fig.savefig(f'{FIGDIR}/fig24_square.png', dpi=150, bbox_inches='tight', facecolor='white')
plt.close()
print('✓ fig24_square.png')

# ===== 图7: 第26题 抛物线 y=x²-4x+3 =====
fig, ax = plt.subplots(figsize=(4.5, 4))
ax.set_xlim(-0.5, 5)
ax.set_ylim(-1.8, 4.5)
ax.axhline(0, color='black', linewidth=0.8)
ax.axvline(0, color='black', linewidth=0.8)
ax.annotate('', xy=(4.8, 0), xytext=(4.5, 0), arrowprops=dict(arrowstyle='->', color='black', lw=1))
ax.annotate('', xy=(0, 4.3), xytext=(0, 4.0), arrowprops=dict(arrowstyle='->', color='black', lw=1))
ax.text(4.85, 0, 'x', fontsize=10, va='center')
ax.text(0.12, 4.35, 'y', fontsize=10)
x = np.linspace(-0.2, 4.5, 300)
y = x**2 - 4*x + 3
ax.plot(x, y, 'b-', linewidth=2.5, label='y=x²-4x+3')
ax.plot(1, 0, 'ro', markersize=7)
ax.plot(3, 0, 'ro', markersize=7)
ax.plot(2, -1, 'g^', markersize=8)
ax.plot(0, 3, 'bs', markersize=6)
ax.text(1.05, 0.2, '(1,0)', fontsize=9, color='red')
ax.text(3.05, 0.2, '(3,0)', fontsize=9, color='red')
ax.text(2.1, -1.2, '顶点(2,-1)', fontsize=9, color='green')
ax.text(0.1, 3.1, '(0,3)', fontsize=9, color='blue')
ax.plot([2, 2], [-1.5, 3.5], 'g--', linewidth=1, alpha=0.5)
ax.text(2.05, 3.55, 'x=2', fontsize=8, color='green')
for i in range(1, 5):
    ax.text(i, -0.2, str(i), fontsize=7, ha='center', color='gray')
for i in range(1, 4):
    ax.text(-0.2, i, str(i), fontsize=7, ha='center', color='gray')
ax.text(-0.2, -1, '-1', fontsize=7, ha='center', color='gray')
ax.axis('off')
ax.axhline(0, color='black', linewidth=0.8)
ax.axvline(0, color='black', linewidth=0.8)
ax.annotate('', xy=(4.8, 0), xytext=(4.5, 0), arrowprops=dict(arrowstyle='->', color='black', lw=1))
ax.annotate('', xy=(0, 4.3), xytext=(0, 4.0), arrowprops=dict(arrowstyle='->', color='black', lw=1))
ax.text(4.85, 0, 'x', fontsize=10, va='center')
ax.text(0.12, 4.35, 'y', fontsize=10)
fig.tight_layout(pad=0.4)
fig.savefig(f'{FIGDIR}/fig26_parabola.png', dpi=150, bbox_inches='tight', facecolor='white')
plt.close()
print('✓ fig26_parabola.png')

# ===== 图8: 第27题 直角梯形ABCD =====
fig, ax = plt.subplots(figsize=(4.0, 3.5))
ax.set_xlim(-0.5, 9.5)
ax.set_ylim(-1.0, 7.5)
ax.set_aspect('equal')
# 直角梯形：B在原点，∠ABC=90°，BC=8 沿x轴，AB=6 沿y轴，AD=4 水平
B = np.array([0, 0])
C = np.array([8, 0])
A = np.array([0, 6])
D = np.array([4, 6])
trap = plt.Polygon([A, B, C, D], fill=True, facecolor='#e8f0ff', edgecolor='black', linewidth=2)
ax.add_patch(trap)
# 直角标记（B处）
sq = patches.Rectangle((0, 0), 0.3, 0.3, fill=False, edgecolor='black', linewidth=1.5)
ax.add_patch(sq)
ax.text(-0.4, 0, 'B', fontsize=13, fontweight='bold', ha='center', va='center')
ax.text(8.3, 0, 'C', fontsize=13, fontweight='bold', ha='center', va='center')
ax.text(-0.4, 6, 'A', fontsize=13, fontweight='bold', ha='center', va='center')
ax.text(4.2, 6.3, 'D', fontsize=13, fontweight='bold', ha='center', va='center')
# 标注边长
ax.text(-0.5, 3, 'AB=6', fontsize=9, ha='right', va='center', color='#333')
ax.text(4, -0.4, 'BC=8', fontsize=9, ha='center', va='top', color='#333')
ax.text(2, 6.4, 'AD=4', fontsize=9, ha='center', va='bottom', color='#333')
# 平行标记（AD∥BC）
ax.annotate('', xy=(5, 0), xytext=(4.5, 0), arrowprops=dict(arrowstyle='->', color='blue', lw=1.2))
ax.annotate('', xy=(3, 6), xytext=(2.5, 6), arrowprops=dict(arrowstyle='->', color='blue', lw=1.2))
# 点P在BC上（示意）
P = np.array([3, 0])
ax.plot(*P, 'ro', markersize=7)
ax.text(3, -0.45, 'P', fontsize=11, ha='center', va='top', color='red', fontweight='bold')
ax.annotate('', xy=(2.9, -0.05), xytext=(0.4, -0.05),
            arrowprops=dict(arrowstyle='->', color='red', lw=1.5))
ax.text(1.5, -0.6, 'BP=t', fontsize=9, ha='center', color='red')
ax.axis('off')
fig.tight_layout(pad=0.4)
fig.savefig(f'{FIGDIR}/fig27_trapezoid.png', dpi=150, bbox_inches='tight', facecolor='white')
plt.close()
print('✓ fig27_trapezoid.png')

print('\n所有图形生成完成！')
