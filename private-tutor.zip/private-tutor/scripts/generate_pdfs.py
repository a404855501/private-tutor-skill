#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成第001套 7科试卷 + 学生档案 PDF
字体：Arial Unicode（/Library/Fonts/Arial Unicode.ttf），支持中英文
"""

import os
import re
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, HRFlowable, Table, TableStyle, PageBreak
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors

# ── 字体注册 ───────────────────────────────────────────────
FONT_PATH = "/Library/Fonts/Arial Unicode.ttf"
pdfmetrics.registerFont(TTFont("AU", FONT_PATH))

# ── 样式 ─────────────────────────────────────────────────
def make_styles():
    base = dict(fontName="AU", leading=18)
    return {
        "title":    ParagraphStyle("title",    fontName="AU", fontSize=16, leading=22, alignment=TA_CENTER, spaceAfter=4),
        "subtitle": ParagraphStyle("subtitle", fontName="AU", fontSize=11, leading=16, alignment=TA_CENTER, spaceAfter=8),
        "h2":       ParagraphStyle("h2",       fontName="AU", fontSize=13, leading=20, spaceBefore=10, spaceAfter=4, textColor=colors.HexColor("#1a1a6e")),
        "h3":       ParagraphStyle("h3",       fontName="AU", fontSize=11, leading=18, spaceBefore=6, spaceAfter=3, textColor=colors.HexColor("#333333")),
        "body":     ParagraphStyle("body",     fontName="AU", fontSize=10.5, leading=18, spaceAfter=4, alignment=TA_JUSTIFY),
        "note":     ParagraphStyle("note",     fontName="AU", fontSize=9,   leading=14, textColor=colors.HexColor("#666666"), spaceAfter=4),
        "answer":   ParagraphStyle("answer",   fontName="AU", fontSize=10,  leading=16, textColor=colors.HexColor("#8B0000"), spaceAfter=3),
        "footer":   ParagraphStyle("footer",   fontName="AU", fontSize=8,   leading=12, textColor=colors.grey, alignment=TA_CENTER),
    }

S = make_styles()

# ── 工具函数 ──────────────────────────────────────────────
def hr():
    return HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#cccccc"), spaceAfter=4, spaceBefore=2)

def bold_escape(text):
    """把 **text** 转为 <b>text</b>，同时转义剩余 &<>"""
    # 先转义 & < >（非标签部分），再处理 **bold**
    # 简化处理：直接替换常见符号
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    # 还原已转义的标签（我们自己要用的）
    text = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', text)
    return text

def parse_md_to_flowables(md_text):
    """把Markdown文本转成reportlab flowable列表"""
    flowables = []
    lines = md_text.split("\n")
    i = 0
    in_answer = False  # 是否进入【参考答案】区域

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # 空行
        if not stripped:
            flowables.append(Spacer(1, 3))
            i += 1
            continue

        # 水平分隔线 ---
        if re.match(r'^-{3,}$', stripped):
            flowables.append(hr())
            i += 1
            continue

        # H1 标题
        if stripped.startswith("# "):
            text = stripped[2:].strip()
            flowables.append(Paragraph(bold_escape(text), S["title"]))
            i += 1
            continue

        # H2 标题
        if stripped.startswith("## "):
            text = stripped[3:].strip()
            if "参考答案" in text or "评分标准" in text:
                in_answer = True
                # 答案区前强制分页，方便打印时跳过
                flowables.append(PageBreak())
            flowables.append(Paragraph(bold_escape(text), S["h2"]))
            i += 1
            continue

        # H3 标题
        if stripped.startswith("### "):
            text = stripped[4:].strip()
            flowables.append(Paragraph(bold_escape(text), S["h3"]))
            i += 1
            continue

        # 引用块 >
        if stripped.startswith("> "):
            text = stripped[2:].strip()
            style = S["note"]
            flowables.append(Paragraph("　" + bold_escape(text), style))
            i += 1
            continue

        # 表格
        if stripped.startswith("|"):
            table_lines = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                table_lines.append(lines[i].strip())
                i += 1
            # 过滤分隔行
            table_lines = [l for l in table_lines if not re.match(r'^\|[-| :]+\|$', l)]
            if table_lines:
                data = []
                for tl in table_lines:
                    cells = [c.strip() for c in tl.strip("|").split("|")]
                    data.append(cells)
                if data:
                    col_count = max(len(row) for row in data)
                    # 补齐列
                    for row in data:
                        while len(row) < col_count:
                            row.append("")
                    # 转成Paragraph
                    table_data = []
                    for ri, row in enumerate(data):
                        style = S["answer"] if in_answer else S["body"]
                        fs = 9 if col_count > 5 else 10
                        cell_style = ParagraphStyle("tc", fontName="AU", fontSize=fs, leading=14)
                        table_data.append([Paragraph(bold_escape(c), cell_style) for c in row])

                    col_width = (A4[0] - 30*mm) / col_count
                    t = Table(table_data, colWidths=[col_width]*col_count, repeatRows=1)
                    ts = TableStyle([
                        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#e8eaf6")),
                        ("TEXTCOLOR", (0,0), (-1,0), colors.HexColor("#1a1a6e")),
                        ("FONTNAME", (0,0), (-1,-1), "AU"),
                        ("FONTSIZE", (0,0), (-1,-1), 9),
                        ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#aaaaaa")),
                        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
                        ("TOPPADDING", (0,0), (-1,-1), 3),
                        ("BOTTOMPADDING", (0,0), (-1,-1), 3),
                        ("LEFTPADDING", (0,0), (-1,-1), 4),
                        ("RIGHTPADDING", (0,0), (-1,-1), 4),
                    ])
                    t.setStyle(ts)
                    flowables.append(t)
                    flowables.append(Spacer(1, 4))
            continue

        # 加粗行（满分/建议用时等头部信息）
        if stripped.startswith("**") and stripped.endswith("**") and "\n" not in stripped:
            text = stripped[2:-2]
            p_style = ParagraphStyle("bold_center", fontName="AU", fontSize=10.5, leading=16, alignment=TA_CENTER, spaceAfter=4)
            flowables.append(Paragraph(bold_escape("**" + text + "**"), p_style))
            i += 1
            continue

        # 普通段落
        style = S["answer"] if in_answer and not stripped.startswith("#") else S["body"]
        # 检测是否为答案区域
        if in_answer:
            style = S["answer"]
        flowables.append(Paragraph(bold_escape(stripped), style))
        i += 1

    return flowables


def generate_pdf(md_text, out_path, subject_name):
    """生成单科PDF"""
    doc = SimpleDocTemplate(
        out_path,
        pagesize=A4,
        leftMargin=20*mm,
        rightMargin=20*mm,
        topMargin=18*mm,
        bottomMargin=18*mm,
        title=subject_name,
        author="私家家教系统",
    )

    flowables = parse_md_to_flowables(md_text)

    # 尾部版权行
    flowables.append(Spacer(1, 10))
    flowables.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#1a1a6e")))
    flowables.append(Paragraph("私家家教系统 · 石家庄市初三备考 · 第001套", S["footer"]))

    doc.build(flowables)
    print(f"  ✓ {os.path.basename(out_path)}")


# ── 主程序 ────────────────────────────────────────────────
BASE = "/Users/chebailin/WorkBuddy/Claw/team-mode/私家家教"
OUT  = os.path.join(BASE, "PDF试卷")
os.makedirs(OUT, exist_ok=True)

tasks = [
    ("学生档案",   os.path.join(BASE, "学习报告/学生档案.md"),           "学生档案"),
    ("语文",       os.path.join(BASE, "每日试卷/第001套_语文试卷.md"),    "第001套·语文"),
    ("数学",       os.path.join(BASE, "每日试卷/2026-03-17_数学_第001号试卷.md"), "第001套·数学"),
    ("英语",       os.path.join(BASE, "每日试卷/第001套_英语试卷.md"),    "第001套·英语"),
    ("物理",       os.path.join(BASE, "每日试卷/第001套_物理试卷.md"),    "第001套·物理"),
    ("化学",       os.path.join(BASE, "每日试卷/第001套_化学试卷.md"),    "第001套·化学"),
    ("历史",       os.path.join(BASE, "每日试卷/第001套_历史试卷.md"),    "第001套·历史"),
    ("道德与法治", os.path.join(BASE, "每日试卷/第001套_道德与法治试卷.md"), "第001套·道法"),
]

print("开始生成PDF...")
for name, md_path, subject in tasks:
    with open(md_path, "r", encoding="utf-8") as f:
        md_text = f.read()
    out_file = os.path.join(OUT, f"第001套_{name}.pdf")
    generate_pdf(md_text, out_file, subject)

print(f"\n全部完成！输出目录：{OUT}")
print("文件列表：")
for f in sorted(os.listdir(OUT)):
    size = os.path.getsize(os.path.join(OUT, f))
    print(f"  {f}  ({size//1024} KB)")
