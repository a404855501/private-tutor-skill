#!/usr/bin/env python3
"""
将 Markdown 数学试卷中的 LaTeX 公式标记转换为普通文字
处理范围：$...$  $$...$$  \dfrac  \sqrt  \begin{cases}  等
"""
import re

MD_PATH = '/Users/chebailin/WorkBuddy/Claw/team-mode/私家家教/每日试卷/2026-03-17_数学_第001号试卷.md'

with open(MD_PATH, 'r', encoding='utf-8') as f:
    text = f.read()

# ── 第一步：处理 $$...$$ 块（解答题步骤） ───────────────────────────
def clean_display_math(m):
    inner = m.group(1).strip()
    return convert_expr(inner)

# ── 核心转换函数 ────────────────────────────────────────────────────
def convert_expr(s):
    s = s.strip()

    # \begin{cases}...\end{cases} → 分行显示
    def cases_repl(m):
        lines = m.group(1).split(r'\\')
        return '  '.join(l.strip() for l in lines if l.strip())
    s = re.sub(r'\\begin\{cases\}(.*?)\\end\{cases\}', cases_repl, s, flags=re.DOTALL)

    # \dfrac{a}{b} 或 \frac{a}{b} → a/b
    def frac_repl(m):
        num = convert_expr(m.group(1))
        den = convert_expr(m.group(2))
        # 如果分子分母都是简单数字/字母，用 a/b 形式
        if len(num) <= 3 and len(den) <= 3:
            return f'{num}/{den}'
        return f'({num})/({den})'
    s = re.sub(r'\\d?frac\{([^{}]+)\}\{([^{}]+)\}', frac_repl, s)

    # \sqrt{...} → √(...)，\sqrt{x} → √x
    def sqrt_repl(m):
        inner = convert_expr(m.group(1))
        if len(inner) == 1:
            return f'√{inner}'
        return f'√({inner})'
    s = re.sub(r'\\sqrt\{([^{}]+)\}', sqrt_repl, s)

    # \left( ... \right) → ( ... )
    s = re.sub(r'\\left\(', '(', s)
    s = re.sub(r'\\right\)', ')', s)
    s = re.sub(r'\\left\[', '[', s)
    s = re.sub(r'\\right\]', ']', s)

    # 上标 x^{n} 或 x^n
    def sup_repl(m):
        base = m.group(1)
        exp  = m.group(2)
        # 常见上标用Unicode上标字符
        sup_map = {'2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹','0':'⁰','1':'¹',
                   'n':'ⁿ'}
        if exp in sup_map:
            return base + sup_map[exp]
        return f'{base}^{exp}'
    # x^{abc}
    s = re.sub(r'([a-zA-Z0-9\)]+)\^\{([^{}]+)\}', lambda m: sup_repl_long(m), s)
    # x^n (单字符)
    s = re.sub(r'([a-zA-Z0-9\)]+)\^([0-9a-zA-Z])', sup_repl, s)

    # 下标 x_{n} 或 x_n
    s = re.sub(r'([a-zA-Z]+)_\{([^{}]+)\}', lambda m: m.group(1) + convert_sub(m.group(2)), s)
    s = re.sub(r'([a-zA-Z]+)_([0-9a-zA-Z])', lambda m: m.group(1) + convert_sub(m.group(2)), s)

    # 特殊符号
    s = s.replace(r'\parallel', '∥')
    s = s.replace(r'\leq', '≤')
    s = s.replace(r'\geq', '≥')
    s = s.replace(r'\neq', '≠')
    s = s.replace(r'\cdot', '·')
    s = s.replace(r'\ldots', '…')
    s = s.replace(r'\times', '×')
    s = s.replace(r'\div', '÷')
    s = s.replace(r'\sin', 'sin')
    s = s.replace(r'\cos', 'cos')
    s = s.replace(r'\tan', 'tan')
    s = s.replace(r'\to', '→')
    s = s.replace(r'\infty', '∞')
    s = s.replace(r'\angle', '∠')
    s = s.replace(r'\triangle', '△')
    s = s.replace(r'\therefore', '∴')
    s = s.replace(r'\because', '∵')
    s = s.replace(r'\quad', '  ')
    s = s.replace(r'\\ ', '  ')
    s = s.replace(r'\\', '  ')
    s = s.replace(r'\ ', ' ')

    # 去掉剩余反斜杠命令（\text{} 等）
    s = re.sub(r'\\text\{([^{}]*)\}', r'\1', s)
    s = re.sub(r'\\[a-zA-Z]+\{([^{}]*)\}', r'\1', s)
    s = re.sub(r'\\[a-zA-Z]+', '', s)

    # 清理多余空格
    s = re.sub(r'  +', ' ', s).strip()
    return s

def sup_repl_long(m):
    base = m.group(1)
    exp  = m.group(2)
    sup_map = {'2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹','0':'⁰','1':'¹'}
    if len(exp) == 1 and exp in sup_map:
        return base + sup_map[exp]
    return f'{base}^{exp}'

def convert_sub(s):
    sub_map = {'0':'₀','1':'₁','2':'₂','3':'₃','4':'₄',
               '5':'₅','6':'₆','7':'₇','8':'₈','9':'₉'}
    if len(s) == 1 and s in sub_map:
        return sub_map[s]
    return s

# ── 第二步：处理 $$...$$ 块 ─────────────────────────────────────────
def replace_display(m):
    inner = m.group(1).strip()
    result = convert_expr(inner)
    return result  # 不加换行，让PDF渲染处理
text = re.sub(r'\$\$(.*?)\$\$', replace_display, text, flags=re.DOTALL)

# ── 第三步：处理 $...$ 行内公式 ─────────────────────────────────────
def replace_inline(m):
    inner = m.group(1)
    return convert_expr(inner)
text = re.sub(r'\$([^$\n]+?)\$', replace_inline, text)

# ── 第四步：清理残余美元符号 ─────────────────────────────────────────
text = text.replace('$', '')

with open(MD_PATH, 'w', encoding='utf-8') as f:
    f.write(text)

# 检查是否还有残余 $
remaining = text.count('$')
print(f'转换完成！残余 $ 符号：{remaining} 个')
if remaining > 0:
    for i, line in enumerate(text.split('\n'), 1):
        if '$' in line:
            print(f'  第{i}行: {line[:80]}')
